import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Shield, BarChart2, BookOpen } from 'lucide-react';
import { MOCK_COINS, MOCK_NEWS } from '../data';
import { CoinTickerItem, NewsGridItem } from '../components/Features';
import { Button, SectionTitle, Card } from '../components/UI';

export const HomePage: React.FC = () => {
  return (
    <div className="space-y-16 pb-12">
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 md:pt-32 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-100 via-transparent to-transparent dark:from-blue-900/20 dark:via-slate-950 dark:to-slate-950 opacity-70"></div>
        <div className="container mx-auto px-4 text-center max-w-4xl">
          <div className="inline-flex items-center px-3 py-1 rounded-full border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-xs font-bold uppercase tracking-wide mb-6">
            DAS DACH KRYPTO HUB #1
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-6">
            Verstehe die Blockchain. <br/>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-cyan-500">Investiere mit System.</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-2xl mx-auto">
            Objektive Vergleiche, fundiertes Wissen und aktuelle News für Bitcoin, Ethereum und DeFi. Deine Zentrale für digitale Assets.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/compare">
              <Button className="w-full sm:w-auto h-12 px-8 text-lg">
                Börsen vergleichen
              </Button>
            </Link>
            <Link to="/category/Grundlagen">
              <Button variant="outline" className="w-full sm:w-auto h-12 px-8 text-lg">
                Krypto lernen
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Market Ticker Section */}
      <section className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <Card className="col-span-1 md:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-slate-900 dark:text-white flex items-center">
                  <BarChart2 className="w-5 h-5 mr-2 text-blue-500" /> Marktbewegungen
                </h3>
                <Link to="/market" className="text-xs text-blue-600 hover:underline">Alle Assets</Link>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {MOCK_COINS.map(coin => (
                  <CoinTickerItem key={coin.id} coin={coin} />
                ))}
              </div>
           </Card>

           <Card className="bg-gradient-to-br from-slate-900 to-slate-800 text-white border-none">
              <h3 className="font-bold text-lg mb-2">Portfolio Tracker</h3>
              <p className="text-slate-300 text-sm mb-6">Behalte den Überblick über deine Assets über alle Wallets hinweg.</p>
              <div className="space-y-4">
                <div className="bg-white/10 p-3 rounded-lg backdrop-blur-sm">
                   <div className="text-xs text-slate-400 mb-1">Gesamtwert (Demo)</div>
                   <div className="text-2xl font-mono font-bold">€ 12.450,30</div>
                </div>
                <Button className="w-full bg-blue-500 hover:bg-blue-600 border-none">Zum Portfolio</Button>
              </div>
           </Card>
        </div>
      </section>

      {/* Feature Grid (USPs) */}
      <section className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
           <div className="p-4">
             <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center mx-auto mb-4 text-emerald-600 dark:text-emerald-400">
               <Shield className="w-6 h-6" />
             </div>
             <h3 className="font-bold text-lg dark:text-white mb-2">Sicherheit & Regulierung</h3>
             <p className="text-sm text-gray-600 dark:text-gray-400">
               Wir prüfen Anbieter auf BaFin-Lizenzen, Einlagensicherung und technologische Sicherheit.
             </p>
           </div>
           <div className="p-4">
             <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mx-auto mb-4 text-blue-600 dark:text-blue-400">
               <BarChart2 className="w-6 h-6" />
             </div>
             <h3 className="font-bold text-lg dark:text-white mb-2">Echte Vergleiche</h3>
             <p className="text-sm text-gray-600 dark:text-gray-400">
               Kein Marketing-Blabla. Wir vergleichen Gebühren, Spreads und Features knallhart.
             </p>
           </div>
           <div className="p-4">
             <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center mx-auto mb-4 text-purple-600 dark:text-purple-400">
               <BookOpen className="w-6 h-6" />
             </div>
             <h3 className="font-bold text-lg dark:text-white mb-2">Wissen für jeden</h3>
             <p className="text-sm text-gray-600 dark:text-gray-400">
               Von den Grundlagen bis zu komplexen DeFi-Strategien – Wissen verständlich aufbereitet.
             </p>
           </div>
        </div>
      </section>

      {/* Latest News */}
      <section className="container mx-auto px-4">
        <SectionTitle title="Neueste Analysen" subtitle="Markt-Updates und Tech-Deep-Dives" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {MOCK_NEWS.map(article => (
            <NewsGridItem key={article.id} article={article} />
          ))}
        </div>
      </section>

    </div>
  );
};
