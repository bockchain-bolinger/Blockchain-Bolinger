import React, { useState } from 'react';
import { EXCHANGES, WALLETS } from '../data';
import { AffiliateRow, Button, SectionTitle } from '../components/UI';
import { ArrowRightLeft, Wallet, Receipt, Coins } from 'lucide-react';

type TabType = 'exchanges' | 'wallets' | 'tax' | 'staking';

export const ComparisonPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('exchanges');

  const tabs = [
    { id: 'exchanges', label: 'Börsen Vergleich', icon: ArrowRightLeft },
    { id: 'wallets', label: 'Hardware Wallets', icon: Wallet },
    { id: 'tax', label: 'Steuer Tools', icon: Receipt },
    { id: 'staking', label: 'Staking Anbieter', icon: Coins },
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h1 className="text-3xl md:text-5xl font-bold text-slate-900 dark:text-white mb-4">
          Die besten Tools im Vergleich
        </h1>
        <p className="text-gray-600 dark:text-gray-400 text-lg">
          Finde den Anbieter, der zu deiner Strategie passt. Wir analysieren Gebühren, Sicherheit und Benutzerfreundlichkeit.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-10">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex items-center px-6 py-3 rounded-full text-sm font-bold transition-all ${
                isActive 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' 
                : 'bg-white dark:bg-slate-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-700'
              }`}
            >
              <Icon className="w-4 h-4 mr-2" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content Area */}
      <div className="space-y-4 max-w-4xl mx-auto">
        {activeTab === 'exchanges' && (
          <div className="animate-fade-in">
             <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900 p-4 rounded-lg mb-6 text-sm text-blue-800 dark:text-blue-300">
               <strong>Hinweis:</strong> Wir legen besonderen Wert auf Regulierung (BaFin/EU) und Sicherheit der Einlagen.
             </div>
             {EXCHANGES.map((ex, idx) => (
               <AffiliateRow key={ex.id} partner={ex} rank={idx + 1} />
             ))}
          </div>
        )}

        {activeTab === 'wallets' && (
          <div className="animate-fade-in">
            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-900 p-4 rounded-lg mb-6 text-sm text-amber-800 dark:text-amber-300">
               <strong>Not your keys, not your coins:</strong> Wir empfehlen dringend die Nutzung einer Hardware-Wallet für Beträge ab 1.000€.
             </div>
             {WALLETS.map((w, idx) => (
               <AffiliateRow key={w.id} partner={w} rank={idx + 1} />
             ))}
          </div>
        )}

        {(activeTab === 'tax' || activeTab === 'staking') && (
           <div className="text-center py-20 bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-gray-800">
             <div className="inline-block p-4 rounded-full bg-gray-100 dark:bg-slate-800 mb-4">
               <Receipt className="w-8 h-8 text-gray-400" />
             </div>
             <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Demnächst verfügbar</h3>
             <p className="text-gray-500">Wir arbeiten gerade an der Analyse für diesen Bereich.</p>
           </div>
        )}
      </div>

    </div>
  );
};
