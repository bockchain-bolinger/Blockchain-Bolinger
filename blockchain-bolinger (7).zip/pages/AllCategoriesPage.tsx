import React from 'react';
import { Link } from 'react-router-dom';
import { CORE_CATEGORIES } from '../data';
import { ArrowRight, BookOpen, Layers, Shield, Coins, Activity, Globe, Scale } from 'lucide-react';
import { SectionTitle, Card } from '../components/UI';

export const AllCategoriesPage: React.FC = () => {
  // Helper to get an icon for a category (simple mapping for demo purposes)
  const getIcon = (category: string) => {
    if (category.includes('Bitcoin')) return Coins;
    if (category.includes('Sicherheit')) return Shield;
    if (category.includes('Web3')) return Globe;
    if (category.includes('Regulierung')) return Scale;
    if (category.includes('Grundlagen')) return BookOpen;
    if (category.includes('Trading')) return Activity;
    return Layers;
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h1 className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mb-6">
          Alle Themenbereiche
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-400">
          Entdecke unser gesamtes Wissen. Von den absoluten Grundlagen bis zu tiefgehenden Analysen der Blockchain-Technologie.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {CORE_CATEGORIES.map((cat) => {
          const Icon = getIcon(cat);
          return (
            <Link key={cat} to={`/category/${encodeURIComponent(cat)}`} className="group block h-full">
              <Card className="h-full hover:border-blue-500 dark:hover:border-blue-500 transition-all duration-300 group-hover:shadow-lg group-hover:-translate-y-1">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {cat}
                    </h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                      Alles über {cat}, Anleitungen, News und Hintergründe.
                    </p>
                    <div className="flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300 transform translate-x-[-10px] group-hover:translate-x-0">
                      Entdecken <ArrowRight className="w-4 h-4 ml-1" />
                    </div>
                  </div>
                </div>
              </Card>
            </Link>
          );
        })}
      </div>
    </div>
  );
};