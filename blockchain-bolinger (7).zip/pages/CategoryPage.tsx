import React from 'react';
import { useParams } from 'react-router-dom';
import { MOCK_NEWS } from '../data';
import { NewsGridItem } from '../components/Features';
import { SectionTitle } from '../components/UI';

export const CategoryPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const decodedId = decodeURIComponent(id || '');

  // In a real app, we would filter news or fetch from API based on category ID
  // For demo, we just show all mock news
  
  return (
    <div className="container mx-auto px-4 py-12">
       <div className="mb-12 border-b border-gray-200 dark:border-gray-800 pb-8">
         <span className="text-blue-600 dark:text-blue-400 font-bold uppercase tracking-wide text-xs">Themenwelt</span>
         <h1 className="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white mt-2">
           {decodedId}
         </h1>
         <p className="text-gray-600 dark:text-gray-400 mt-4 max-w-3xl text-lg">
           Alles was du über {decodedId} wissen musst. Aktuelle News, Anleitungen und Analysen von unseren Experten.
         </p>
       </div>

       <SectionTitle title="Neueste Artikel" />
       
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
         {/* Simulating filtered content */}
          {MOCK_NEWS.map(article => (
            <NewsGridItem key={article.id} article={article} />
          ))}
          {MOCK_NEWS.map(article => (
            <NewsGridItem key={`${article.id}-copy`} article={{...article, id: `${article.id}-copy`, title: `Deep Dive: ${article.title}`}} />
          ))}
       </div>
    </div>
  );
};
