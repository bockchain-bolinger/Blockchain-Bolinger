import React, { useEffect, useState, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { PortfolioApi, CoinsApi } from '../packages/sdk/src';
import { Coin, PortfolioPosition } from '../types';
import { PageHeader } from '../components/layout/PageHeader';
import { PortfolioSummary } from '../components/portfolio/PortfolioSummary';
import { PortfolioTable, PortfolioRow } from '../components/portfolio/PortfolioTable';
import { Button, Card } from '../components/UI';
import { PlusCircle, Wallet } from 'lucide-react';
import { Link } from 'react-router-dom';

export const PortfolioPage: React.FC = () => {
  const { user } = useAuth();
  const [positions, setPositions] = useState<PortfolioPosition[]>([]);
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Daten laden
  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        // Parallel: Portfolio & aktuelle Coin-Preise laden
        // Note: SDK structure might differ in real environment, using what is imported
        const [portfolioData, coinsData] = await Promise.all([
          PortfolioApi.getPositions(), // Updated to match likely SDK method signature (usually getPositions or getPortfolio)
          CoinsApi.getAll(100)
        ]);
        setPositions(portfolioData);
        setCoins(coinsData);
      } catch (err) {
        console.error("Failed to load portfolio data", err);
        // Fallback for demo if API fails
        setPositions([
             { id: '1', coinId: 'bitcoin', amount: 0.5, avgBuyPriceEur: 35000 },
             { id: '2', coinId: 'ethereum', amount: 5, avgBuyPriceEur: 2000 },
        ]);
        // setError("Fehler beim Laden deines Portfolios. (Demo Modus aktiv)");
        // Try to fetch coins again or use Mock if coins failed
        if (coins.length === 0) {
             const mockCoins = await CoinsApi.getAll(20).catch(() => []);
             setCoins(mockCoins);
        }
        setLoading(false);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  // Berechnungen (Memoized für Performance)
  const portfolioData = useMemo(() => {
    let totalValue = 0;
    let totalInvested = 0;

    const rows: PortfolioRow[] = positions.map(pos => {
      // Finde aktuellen Preis des Coins
      const coin = coins.find(c => c.id === pos.coinId || c.slug === pos.coinId);
      const currentPrice = coin?.priceEur || 0;
      
      const currentValue = pos.amount * currentPrice;
      const investedValue = pos.amount * (pos.avgBuyPriceEur || 0);
      const pnlAbs = currentValue - investedValue;
      const pnlPercent = investedValue > 0 ? (pnlAbs / investedValue) * 100 : 0;

      totalValue += currentValue;
      totalInvested += investedValue;

      return {
        ...pos,
        coinName: coin?.name || pos.coinId,
        coinSymbol: coin?.symbol || '???',
        coinSlug: coin?.slug || '',
        currentPriceEur: currentPrice,
        currentValueEur: currentValue,
        pnlEur: pnlAbs,
        pnlPercent: pnlPercent,
        change24h: coin?.change24h || 0
      };
    });

    const totalPnL = totalValue - totalInvested;
    const totalPnLPercent = totalInvested > 0 ? (totalPnL / totalInvested) * 100 : 0;

    return { rows, totalValue, totalPnL, totalPnLPercent };
  }, [positions, coins]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <PageHeader 
          title="Dein Portfolio" 
          subtitle="Behalte den Überblick über deine Assets und Performance."
          className="mb-0"
        />
        <Button className="flex items-center gap-2">
          <PlusCircle className="w-4 h-4" /> Position hinzufügen
        </Button>
      </div>

      {error && (
        <div className="bg-amber-50 text-amber-700 p-4 rounded-lg mb-8 border border-amber-200">
          {error}
        </div>
      )}

      {positions.length > 0 ? (
        <>
          {/* Summary Cards */}
          <PortfolioSummary 
            totalValueEur={portfolioData.totalValue}
            totalPnLAbs={portfolioData.totalPnL}
            totalPnLPercent={portfolioData.totalPnLPercent}
          />

          {/* Table */}
          <div className="mt-12">
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-4">Positionen</h2>
            <PortfolioTable rows={portfolioData.rows} />
          </div>
        </>
      ) : (
        /* Empty State */
        <Card className="text-center py-16">
          <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600 dark:text-blue-400">
            <Wallet className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Noch keine Positionen</h3>
          <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-8">
            Dein Portfolio ist leer. Starte jetzt, indem du deine ersten Krypto-Investitionen hinzufügst oder Börsen vergleichst.
          </p>
          <div className="flex justify-center gap-4">
            <Button>Position manuell erfassen</Button>
            <Link to="/compare">
              <Button variant="outline">Börsen vergleichen</Button>
            </Link>
          </div>
        </Card>
      )}
    </div>
  );
};