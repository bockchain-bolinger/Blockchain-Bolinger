import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { PortfolioApi, CoinsApi } from '../packages/sdk/src';
import { Coin, WatchlistItem } from '../types';
import { PageHeader } from '../components/layout/PageHeader';
import { WatchlistTable, WatchlistRow } from '../components/portfolio/WatchlistTable';
import { Button, Card } from '../components/UI';
import { Star, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

export const WatchlistPage: React.FC = () => {
  const { user } = useAuth();
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false); // Für Remove-Aktionen

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [wlData, coinsData] = await Promise.all([
        PortfolioApi.getWatchlist(),
        CoinsApi.getAll(100)
      ]);
      setWatchlist(wlData);
      setCoins(coinsData);
    } catch (err) {
      console.error(err);
      // Demo Fallback
      setWatchlist([
          { id: '1', coinId: 'solana', addedAt: new Date().toISOString() },
          { id: '2', coinId: 'cardano', addedAt: new Date().toISOString() }
      ]);
      if (coins.length === 0) {
          const mockCoins = await CoinsApi.getAll(20).catch(() => []);
          setCoins(mockCoins);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (coinId: string) => {
    if (!user || processing) return;
    setProcessing(true);
    try {
      await PortfolioApi.removeFromWatchlist(coinId);
      
      // State aktualisieren
      setWatchlist(prev => prev.filter(item => item.coinId !== coinId));
    } catch (err) {
      console.error("Failed to remove item", err);
      // Fallback for demo - optimistic update even if API fails
      setWatchlist(prev => prev.filter(item => item.coinId !== coinId));
    } finally {
      setProcessing(false);
    }
  };

  // Mappe Watchlist-Items auf Rows mit Preisdaten
  const rows: WatchlistRow[] = watchlist.map(item => {
    const coin = coins.find(c => c.id === item.coinId || c.slug === item.coinId);
    return {
      id: item.id,
      coinId: item.coinId,
      coinName: coin?.name || 'Unbekannt',
      coinSymbol: coin?.symbol || '',
      coinSlug: coin?.slug || '',
      currentPriceEur: coin?.priceEur || 0,
      change24h: coin?.change24h || 0
    };
  });

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <PageHeader 
          title="Deine Watchlist" 
          subtitle="Beobachte interessante Coins und verpasse keine Chance."
          className="mb-0"
        />
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input 
            type="text" 
            placeholder="Coin hinzufügen..." 
            className="pl-9 pr-4 py-2 rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm w-full md:w-64"
          />
        </div>
      </div>

      {rows.length > 0 ? (
        <Card noPadding className="overflow-hidden">
          <WatchlistTable rows={rows} onRemove={handleRemove} />
        </Card>
      ) : (
        <Card className="text-center py-16">
          <div className="w-16 h-16 bg-amber-50 dark:bg-amber-900/20 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-500">
            <Star className="w-8 h-8 fill-current" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Deine Watchlist ist leer</h3>
          <p className="text-gray-500 dark:text-gray-400 max-w-md mx-auto mb-8">
            Du beobachtest noch keine Coins. Füge Favoriten hinzu, um deren Preisentwicklung im Blick zu behalten.
          </p>
          <Link to="/">
            <Button>Marktübersicht ansehen</Button>
          </Link>
        </Card>
      )}
    </div>
  );
};