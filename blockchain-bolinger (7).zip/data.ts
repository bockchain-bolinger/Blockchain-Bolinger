import { AffiliatePartner, CategoryType, Coin, NewsArticle } from './types';

export const CORE_CATEGORIES = Object.values(CategoryType);

export const MOCK_COINS: Coin[] = [
  { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin', slug: 'bitcoin', priceEur: 62450.20, change24h: 2.5, marketCap: 1200000000 },
  { id: 'ethereum', symbol: 'ETH', name: 'Ethereum', slug: 'ethereum', priceEur: 3105.45, change24h: -1.2, marketCap: 380000000 },
  { id: 'solana', symbol: 'SOL', name: 'Solana', slug: 'solana', priceEur: 145.20, change24h: 5.8, marketCap: 65000000 },
  { id: 'bnb', symbol: 'BNB', name: 'Binance Coin', slug: 'binance-coin', priceEur: 540.10, change24h: 0.5, marketCap: 80000000 },
  { id: 'cardano', symbol: 'ADA', name: 'Cardano', slug: 'cardano', priceEur: 0.45, change24h: -0.8, marketCap: 16000000 },
];

export const EXCHANGES: AffiliatePartner[] = [
  {
    id: 'bsdex',
    name: 'BSDEX',
    slug: 'bsdex',
    url: 'https://www.bsdex.de',
    type: 'EXCHANGE',
    logoUrl: 'https://picsum.photos/50/50?random=1',
    rating: 4.8,
    bonus: 'Made in Germany',
    features: ['Reguliert in DE', 'Niedrige Gebühren', 'Börse Stuttgart'],
    link: '#',
    isRecommended: true
  },
  {
    id: 'bitpanda',
    name: 'Bitpanda',
    slug: 'bitpanda',
    url: 'https://www.bitpanda.com',
    type: 'EXCHANGE',
    logoUrl: 'https://picsum.photos/50/50?random=2',
    rating: 4.7,
    bonus: '50€ Neukundenbonus',
    features: ['BaFin Lizenz', 'Sparpläne', 'Metals & Stocks'],
    link: '#'
  },
  {
    id: 'binance',
    name: 'Binance',
    slug: 'binance',
    url: 'https://www.binance.com',
    type: 'EXCHANGE',
    logoUrl: 'https://picsum.photos/50/50?random=3',
    rating: 4.5,
    bonus: '100 USDT Rebate',
    features: ['Größte Auswahl', 'Hohe Liquidität', 'Pro Trading Tools'],
    link: '#'
  }
];

export const WALLETS: AffiliatePartner[] = [
  {
    id: 'ledger',
    name: 'Ledger Nano X',
    slug: 'ledger-nano-x',
    url: 'https://www.ledger.com',
    type: 'WALLET',
    logoUrl: 'https://picsum.photos/50/50?random=4',
    rating: 4.9,
    bonus: 'Kostenloser Versand',
    features: ['Bluetooth', 'CC EAL5+ Chip', 'Unterstützt 5500+ Coins'],
    link: '#',
    isRecommended: true
  },
  {
    id: 'trezor',
    name: 'Trezor Model T',
    slug: 'trezor-model-t',
    url: 'https://trezor.io',
    type: 'WALLET',
    logoUrl: 'https://picsum.photos/50/50?random=5',
    rating: 4.6,
    bonus: '',
    features: ['Touchscreen', 'Open Source', 'Shamir Backup'],
    link: '#'
  }
];

export const MOCK_NEWS: NewsArticle[] = [
  {
    id: '1',
    slug: 'bitcoin-halving-2024',
    title: 'Bitcoin Halving 2024: Was Anleger jetzt wissen müssen',
    excerpt: 'Das Halving steht kurz bevor. Historisch gesehen ein Preistreiber, doch ist dieses Mal alles anders?',
    category: CategoryType.BTC_ETH,
    date: '12. Okt 2023',
    imageUrl: 'https://picsum.photos/800/400?random=10',
    readTime: '5 min'
  },
  {
    id: '2',
    slug: 'mica-verordnung-eu',
    title: 'MiCA-Verordnung: Das ändert sich für Krypto-Startups in der EU',
    excerpt: 'Die neue Regulierung bringt Klarheit, aber auch Hürden. Ein Deep-Dive in die Compliance.',
    category: CategoryType.REGULATION,
    date: '10. Okt 2023',
    imageUrl: 'https://picsum.photos/800/400?random=11',
    readTime: '8 min'
  },
  {
    id: '3',
    slug: 'real-world-assets-blackrock',
    title: 'Real World Assets (RWA): Der nächste Billionen-Dollar-Markt?',
    excerpt: 'Wie BlackRock und Co. Immobilien und Anleihen auf die Blockchain bringen.',
    category: CategoryType.RWA,
    date: '08. Okt 2023',
    imageUrl: 'https://picsum.photos/800/400?random=12',
    readTime: '6 min'
  }
];
