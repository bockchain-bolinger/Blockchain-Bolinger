
import { apiGet } from './client';
import { NewsArticle } from '../../../types';

export const news = {
  // Neueste News abrufen
  getAll: (limit = 10, category?: string) => {
    const query = category ? `?limit=${limit}&category=${category}` : `?limit=${limit}`;
    return apiGet<NewsArticle[]>(`/news${query}`);
  },

  // Einzelnen Artikel abrufen
  getBySlug: (slug: string) => 
    apiGet<NewsArticle>(`/news/${slug}`),
    
  // Ähnliche Artikel
  getRelated: (id: string) => 
    apiGet<NewsArticle[]>(`/news/${id}/related`),
};
