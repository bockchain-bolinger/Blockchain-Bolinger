
import { apiGet } from './client';
import { Exchange, Wallet, TaxTool, StakingPlatform } from '../../../types';

export const tools = {
  // Exchanges
  getExchanges: (dachFriendlyOnly = false) => 
    apiGet<Exchange[]>(`/tools/exchanges?dach=${dachFriendlyOnly}`),
    
  getExchangeBySlug: (slug: string) => 
    apiGet<Exchange>(`/tools/exchanges/${slug}`),

  // Wallets
  getWallets: (type?: 'HARDWARE' | 'SOFTWARE') => {
    const query = type ? `?type=${type}` : '';
    return apiGet<Wallet[]>(`/tools/wallets${query}`);
  },

  // Tax Tools
  getTaxTools: () => 
    apiGet<TaxTool[]>('/tools/tax-tools'),

  // Staking Platforms
  getStakingPlatforms: () => 
    apiGet<StakingPlatform[]>('/tools/staking'),
};
