
import { apiGet } from './client';
import { Coin, MarketData } from '../../../types';

export const coins = {
  // Alle Coins abrufen (paginiert)
  getAll: (limit = 20, offset = 0) => 
    apiGet<Coin[]>(`/coins?limit=${limit}&offset=${offset}`),

  // Einzelnen Coin per ID oder Slug abrufen
  getById: (id: string) => 
    apiGet<Coin>(`/coins/${id}`),

  // Preishistorie abrufen
  getHistory: (id: string, range: '24h' | '7d' | '30d' | '1y' = '7d') => 
    apiGet<MarketData[]>(`/coins/${id}/history?range=${range}`),
    
  // Trending Coins
  getTrending: () => 
    apiGet<Coin[]>('/coins/trending'),
};
