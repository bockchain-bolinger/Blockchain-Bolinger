
import { apiPost, apiGet } from './client';
import { User } from '../../../types';

export interface AuthResponse {
  access_token: string;
  user: User;
}

export const auth = {
  login: (credentials: { email: string; password: string }) => 
    apiPost<AuthResponse>('/auth/login', credentials),

  register: (data: { email: string; password: string }) => 
    apiPost<User>('/auth/register', data),

  logout: () => 
    apiPost<{ message: string }>('/auth/logout', {}),

  getCurrentUser: (token: string) => 
    apiGet<User>('/auth/me', {
      headers: { Authorization: `Bearer ${token}` }
    }),
};
