
import { apiGet, apiPost, apiDelete, apiPut } from './client';
import { PortfolioPosition, WatchlistItem } from '../../../types';

export const portfolio = {
  // --- Portfolio ---
  getPositions: () => 
    apiGet<PortfolioPosition[]>('/portfolio'),

  addPosition: (data: { coinId: string; amount: number; price: number }) => 
    apiPost<PortfolioPosition>('/portfolio', data),

  updatePosition: (id: string, data: { amount?: number; price?: number }) => 
    apiPut<PortfolioPosition>(`/portfolio/${id}`, data),
    
  removePosition: (id: string) => 
    apiDelete<{ success: boolean }>(`/portfolio/${id}`),

  // --- Watchlist ---
  getWatchlist: () => 
    apiGet<WatchlistItem[]>('/watchlist'),
    
  addToWatchlist: (coinId: string) => 
    apiPost<WatchlistItem>('/watchlist', { coinId }),
    
  removeFromWatchlist: (coinId: string) => 
    apiDelete<{ success: boolean }>(`/watchlist/${coinId}`),
};
