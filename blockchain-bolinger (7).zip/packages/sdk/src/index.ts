
import { coins } from './coins';
import { news } from './news';
import { categories } from './categories';
import { tools } from './tools';
import { affiliates } from './affiliates';
import { portfolio } from './portfolio';
import { auth } from './auth';

// Zentraler Client-Export
export const client = {
  coins,
  news,
  categories,
  tools,
  affiliates,
  portfolio,
  auth,
};

export const AuthApi = auth;
export const CoinsApi = coins;
export const ToolsApi = tools;
export const PortfolioApi = portfolio;

// Typen re-exportieren (optional, falls Nutzer direkt aus SDK importieren wollen)
// export * from '../../types';
