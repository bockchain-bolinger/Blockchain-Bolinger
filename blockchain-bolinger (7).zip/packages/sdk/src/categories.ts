
import { apiGet } from './client';
import { Category } from '../../../types';

export const categories = {
  // Alle Kategorien
  getAll: () => 
    apiGet<Category[]>('/categories'),

  // Einzelne Kategorie + Details
  getBySlug: (slug: string) => 
    apiGet<Category>(`/categories/${slug}`),
};
