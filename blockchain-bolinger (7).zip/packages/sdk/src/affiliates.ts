
import { apiGet } from './client';
import { AffiliateProgram } from '../../../types';

export const affiliates = {
  // Liste aller Partnerprogramme
  getAll: () => 
    apiGet<AffiliateProgram[]>('/affiliates'),
    
  // Tracking-Link generieren (oder Redirect URL holen)
  getLink: (slug: string, source = 'web') => 
    apiGet<{ url: string }>(`/affiliates/${slug}/link?source=${source}`),
};
