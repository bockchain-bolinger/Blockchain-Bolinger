
// 10 Core Categories
export enum CategoryType {
  BASICS = 'Grundlagen',
  BTC_ETH = 'Bitcoin & Ethereum',
  TRADING = 'Trading & Analyse',
  DEFI = 'DeFi',
  STAKING = 'Staking & Passive Income',
  NFT_GAMING = 'NFTs & Gaming',
  WEB3 = 'Web3 & dApps',
  SECURITY = 'Sicherheit',
  REGULATION = 'Regulierung & Steuern',
  RWA = 'Tokenisierung & RWAs'
}

// User Model
export interface User {
  id: string;
  email: string;
  role: 'USER' | 'ADMIN';
  createdAt?: string;
}

// Basis-Modelle
export interface Category {
  id: string;
  slug: string;
  name: string;
  description: string;
  type?: CategoryType;
}

export interface Coin {
  id: string;
  symbol: string;
  name: string;
  slug: string;
  priceEur: number;
  change24h: number;
  marketCap: number;
  description?: string;
}

export interface MarketData {
  price: number;
  volume24h: number;
  timestamp: string;
}

export interface NewsArticle {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content?: string;
  category: CategoryType | string;
  date: string;
  imageUrl: string;
  readTime: string;
  source?: string;
}

// Tools & Affiliates
export interface AffiliateProgram {
  id: string;
  slug: string;
  name: string;
  link: string;
  commissionModel?: string;
  isDachFriendly: boolean;
  bonus?: string;
}

export interface ToolBase {
  id: string;
  name: string;
  slug: string;
  url: string;
  logoUrl?: string;
  rating: number;
  features: string[];
  affiliate?: AffiliateProgram;
}

export interface Exchange extends ToolBase {
  country: string;
  kycRequired: boolean;
  fees: { maker: number; taker: number };
  supportsStaking: boolean;
  supportsFiatDeposit: boolean;
}

export interface Wallet extends ToolBase {
  type: 'HARDWARE' | 'SOFTWARE' | 'CUSTODIAL';
  manufacturer?: string;
  supportsBitcoin: boolean;
  supportsEthereum: boolean;
  supportsNFTs: boolean;
}

export interface TaxTool extends ToolBase {
  countryFocus: string[];
  hasFreeTier: boolean;
}

export interface StakingPlatform extends ToolBase {
  minDeposit: number;
  lockupPeriodDays: number;
  apy: number;
}

// User & Portfolio
export interface PortfolioPosition {
  id: string;
  coinId: string;
  amount: number;
  avgBuyPriceEur: number;
  currentValueEur?: number; // Calculated
  profitEur?: number; // Calculated
  profitPercent?: number; // Calculated
  coin?: Coin;
}

export interface WatchlistItem {
  id: string;
  coinId: string;
  addedAt: string;
  coin?: Coin;
}

// Legacy (wird schrittweise durch spezifische Typen ersetzt)
export interface AffiliatePartner extends ToolBase {
  type: 'EXCHANGE' | 'WALLET' | 'TAX_TOOL' | 'STAKING';
  bonus: string;
  link: string;
  isRecommended?: boolean;
}

export interface NavItem {
  label: string;
  path: string;
  category?: CategoryType;
}

export type Theme = 'light' | 'dark';
