import React from 'react';
import { Trash2, TrendingUp, TrendingDown } from 'lucide-react';

export interface WatchlistRow {
  id: string;
  coinId: string;
  coinName: string;
  coinSymbol: string;
  coinSlug: string;
  currentPriceEur: number;
  change24h: number;
}

interface WatchlistTableProps {
  rows: WatchlistRow[];
  onRemove: (coinId: string) => void;
}

export const WatchlistTable: React.FC<WatchlistTableProps> = ({ rows, onRemove }) => {
  return (
    <div className="overflow-x-auto bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-gray-800">
      <table className="w-full text-left border-collapse">
        <thead className="bg-gray-50 dark:bg-slate-800 text-gray-500 dark:text-gray-400 text-xs uppercase font-semibold">
          <tr>
            <th className="px-6 py-4">Coin</th>
            <th className="px-6 py-4 text-right">Preis (EUR)</th>
            <th className="px-6 py-4 text-right">24h Änderung</th>
            <th className="px-6 py-4 text-right">Aktion</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
          {rows.map((row) => {
            const isPositive = row.change24h >= 0;
            return (
              <tr key={row.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-xs font-bold text-indigo-600 dark:text-indigo-400 mr-3">
                      {row.coinSymbol[0]}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{row.coinName}</div>
                      <div className="text-xs text-gray-500">{row.coinSymbol}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-sm font-mono text-gray-700 dark:text-gray-300">
                  €{row.currentPriceEur.toLocaleString('de-DE', { minimumFractionDigits: 2 })}
                </td>
                <td className="px-6 py-4 text-right text-sm">
                  <div className={`inline-flex items-center ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                    {isPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                    {Math.abs(row.change24h)}%
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onRemove(row.coinId)}
                    className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"
                    title="Von Watchlist entfernen"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};