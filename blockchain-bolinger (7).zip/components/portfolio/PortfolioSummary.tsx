import React from 'react';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import { Card } from '../UI';

interface PortfolioSummaryProps {
  totalValueEur: number;
  totalPnLAbs: number;
  totalPnLPercent: number;
}

export const PortfolioSummary: React.FC<PortfolioSummaryProps> = ({ 
  totalValueEur, 
  totalPnLAbs, 
  totalPnLPercent 
}) => {
  const isProfit = totalPnLAbs >= 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {/* Total Value */}
      <Card className="relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Wallet className="w-16 h-16 text-blue-600 dark:text-white" />
        </div>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Gesamtwert</p>
        <h3 className="text-3xl font-bold text-slate-900 dark:text-white">
          {new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(totalValueEur)}
        </h3>
      </Card>

      {/* PnL Absolute */}
      <Card>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Gewinn/Verlust (Gesamt)</p>
        <div className={`text-2xl font-bold flex items-center ${isProfit ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
          {isProfit ? '+' : ''}{new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(totalPnLAbs)}
        </div>
        <p className="text-xs text-gray-400 mt-1">Seit Beginn</p>
      </Card>

      {/* PnL Percent */}
      <Card>
        <p className="text-sm font-medium text-gray-500 dark:text-gray-400 mb-1">Performance</p>
        <div className={`text-2xl font-bold flex items-center ${isProfit ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
          {isProfit ? <TrendingUp className="w-6 h-6 mr-2" /> : <TrendingDown className="w-6 h-6 mr-2" />}
          {totalPnLPercent.toFixed(2)}%
        </div>
        <p className="text-xs text-gray-400 mt-1">Gewichtet</p>
      </Card>
    </div>
  );
};