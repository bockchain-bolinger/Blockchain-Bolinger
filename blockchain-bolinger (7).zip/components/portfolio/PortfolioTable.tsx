import React from 'react';
import { PortfolioPosition } from '../../types';

export interface PortfolioRow extends PortfolioPosition {
  coinName: string;
  coinSymbol: string;
  coinSlug: string;
  currentPriceEur: number;
  currentValueEur: number;
  pnlEur: number;
  pnlPercent: number;
  change24h: number;
}

interface PortfolioTableProps {
  rows: PortfolioRow[];
}

export const PortfolioTable: React.FC<PortfolioTableProps> = ({ rows }) => {
  return (
    <div className="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-800 shadow-sm bg-white dark:bg-slate-900">
      <table className="w-full text-left border-collapse">
        <thead className="bg-gray-50 dark:bg-slate-800 text-gray-500 dark:text-gray-400 text-xs uppercase font-semibold">
          <tr>
            <th className="px-6 py-4">Asset</th>
            <th className="px-6 py-4 text-right">Menge</th>
            <th className="px-6 py-4 text-right">Preis</th>
            <th className="px-6 py-4 text-right">Wert</th>
            <th className="px-6 py-4 text-right">G/V (Gesamt)</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
          {rows.map((row) => {
            const isProfit = row.pnlEur >= 0;
            return (
              <tr key={row.id} className="hover:bg-gray-50/50 dark:hover:bg-slate-800/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-xs font-bold text-blue-600 dark:text-blue-400 mr-3">
                      {row.coinSymbol[0]}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 dark:text-white">{row.coinName}</div>
                      <div className="text-xs text-gray-500">{row.coinSymbol}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-sm text-gray-700 dark:text-gray-300">
                  {row.amount.toLocaleString()} <span className="text-gray-400 text-xs">{row.coinSymbol}</span>
                </td>
                <td className="px-6 py-4 text-right text-sm">
                  <div className="text-slate-900 dark:text-white font-medium">
                    €{row.currentPriceEur.toLocaleString('de-DE', { minimumFractionDigits: 2 })}
                  </div>
                  <div className={`text-xs ${row.change24h >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                    {row.change24h > 0 ? '+' : ''}{row.change24h}% (24h)
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-sm font-bold text-slate-900 dark:text-white">
                  €{row.currentValueEur.toLocaleString('de-DE', { minimumFractionDigits: 2 })}
                </td>
                <td className="px-6 py-4 text-right text-sm">
                  <div className={`font-medium ${isProfit ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                    {isProfit ? '+' : ''}€{row.pnlEur.toLocaleString('de-DE', { minimumFractionDigits: 2 })}
                  </div>
                  <div className={`text-xs ${isProfit ? 'text-emerald-500' : 'text-red-500'}`}>
                    {row.pnlPercent.toFixed(2)}%
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};