
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Moon, Sun, ChevronDown, Search, Activity, ChevronRight, CornerDownRight, Grid, LogOut, User } from 'lucide-react';
import { useGlobal } from '../context/GlobalContext';
import { useAuth } from '../context/AuthContext';
import { CORE_CATEGORIES } from '../data';

// Helper to structure categories with sub-items for the dropdown
const getCategoryStructure = () => {
  return CORE_CATEGORIES.map(cat => {
    const item = { 
      label: cat, 
      path: `/category/${encodeURIComponent(cat)}`, 
      subItems: [] as {label: string, path: string}[] 
    };

    if (cat === 'Bitcoin & Ethereum') {
      item.subItems = [
        { label: 'Bitcoin', path: '/category/Bitcoin' },
        { label: 'Ethereum', path: '/category/Ethereum' },
        { label: 'Altcoins', path: '/category/Altcoins' },
      ];
    }
    
    if (cat === 'DeFi') {
      item.subItems = [
        { label: 'Lending', path: '/category/Lending' },
        { label: 'DEXs', path: '/category/DEXs' },
        { label: 'Yield Farming', path: '/category/Yield' },
      ];
    }

    return item;
  });
};

const CATEGORY_TREE = getCategoryStructure();

export const Navbar: React.FC = () => {
  const { theme, toggleTheme } = useGlobal();
  const { user, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCategoryOpen, setIsCategoryOpen] = useState(false);
  const location = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const timeoutRef = useRef<number | null>(null);

  const isActive = (path: string) => location.pathname === path;

  // Close menus on route change
  useEffect(() => {
    setIsMenuOpen(false);
    setIsCategoryOpen(false);
  }, [location.pathname]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsCategoryOpen(false);
      }
    };

    if (isCategoryOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isCategoryOpen]);

  // Handlers for accessible hover and focus behavior
  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsCategoryOpen(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = window.setTimeout(() => {
      setIsCategoryOpen(false);
    }, 300);
  };

  const handleFocus = () => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsCategoryOpen(true);
  };

  const handleBlur = (event: React.FocusEvent) => {
    // Only close if focus moves outside the dropdown container
    if (!dropdownRef.current?.contains(event.relatedTarget as Node)) {
       setIsCategoryOpen(false);
    }
  };

  // Advanced Keyboard Navigation for Dropdown
  const handleKeyDown = (event: React.KeyboardEvent) => {
    // 1. Close on Escape
    if (event.key === 'Escape') {
      event.preventDefault();
      setIsCategoryOpen(false);
      buttonRef.current?.focus();
      return;
    }

    // 2. Open with ArrowDown/Enter/Space if closed
    if (!isCategoryOpen) {
      if (['ArrowDown', 'Enter', ' '].includes(event.key)) {
        event.preventDefault();
        setIsCategoryOpen(true);
        // Auto-focus first item on arrow down/enter
        setTimeout(() => {
           const firstItem = dropdownRef.current?.querySelector('a[href], button:not([disabled]):not(#category-menu-button)') as HTMLElement;
           firstItem?.focus();
        }, 0);
      }
      return;
    }

    // 3. Navigation when open
    if (isCategoryOpen) {
      const keys = ['ArrowDown', 'ArrowUp', 'Home', 'End'];
      if (keys.includes(event.key)) {
        event.preventDefault();
        
        const focusableSelector = 'a[href], button:not([disabled])';
        const focusableElements = dropdownRef.current?.querySelectorAll(focusableSelector);
        
        if (!focusableElements || focusableElements.length === 0) return;

        const items = Array.from(focusableElements) as HTMLElement[];
        const currentIndex = items.indexOf(document.activeElement as HTMLElement);
        
        let nextIndex = 0;

        if (event.key === 'ArrowDown') {
           nextIndex = currentIndex === -1 ? 0 : (currentIndex + 1) % items.length;
        } else if (event.key === 'ArrowUp') {
           nextIndex = currentIndex === -1 ? items.length - 1 : (currentIndex - 1 + items.length) % items.length;
        } else if (event.key === 'Home') {
           nextIndex = 0; // Go to button
        } else if (event.key === 'End') {
           nextIndex = items.length - 1; // Go to last item
        }
        
        items[nextIndex]?.focus();
      }
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-200 dark:border-gray-800 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md transition-colors duration-300">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        
        {/* Brand */}
        <Link to="/" className="flex items-center space-x-2 group focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-lg p-1">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center transition-transform group-hover:scale-110 duration-200 shadow-lg shadow-blue-600/20">
            <Activity className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-cyan-500 dark:from-blue-400 dark:to-cyan-300">
            Blockchain-Bolinger
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center space-x-1">
          <Link 
            to="/" 
            className={`px-3 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 ${isActive('/') ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/10' : 'text-gray-700 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-800'}`}
          >
            Home
          </Link>
          
          {/* Interactive Categories Dropdown */}
          <div 
            className="relative"
            ref={dropdownRef}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
          >
            <button 
              ref={buttonRef}
              id="category-menu-button"
              className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors outline-none focus:ring-2 focus:ring-blue-500 ${
                isCategoryOpen || location.pathname.includes('/category') 
                  ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/10' 
                  : 'text-gray-700 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-800'
              }`}
              onClick={() => setIsCategoryOpen(!isCategoryOpen)}
              aria-expanded={isCategoryOpen}
              aria-haspopup="true"
              aria-controls="category-dropdown"
            >
              Themen 
              <ChevronDown 
                className={`w-4 h-4 ml-1.5 transition-transform duration-300 ease-in-out ${isCategoryOpen ? 'rotate-180' : 'rotate-0'}`} 
              />
            </button>
            
            {/* Dropdown Content */}
            <div 
              id="category-dropdown"
              aria-labelledby="category-menu-button"
              className={`absolute left-0 top-full mt-1 w-72 bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 shadow-xl shadow-slate-200/50 dark:shadow-slate-950/50 rounded-xl overflow-hidden transition-all duration-300 ease-out origin-top-left z-50 transform ${
                isCategoryOpen 
                  ? 'opacity-100 translate-y-0 scale-100 visible' 
                  : 'opacity-0 -translate-y-2 scale-95 invisible'
              }`}
              role="menu"
            >
              {/* Fixed Header: 'All Categories' Link */}
              <div className="p-2 border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-slate-900 sticky top-0 z-10">
                <Link
                  to="/categories"
                  role="menuitem"
                  className="flex items-center px-3 py-2.5 rounded-lg text-sm font-bold text-slate-900 dark:text-white hover:bg-blue-50 dark:hover:bg-blue-900/20 hover:text-blue-600 dark:hover:text-blue-400 transition-colors focus:outline-none focus:bg-blue-50 dark:focus:bg-blue-900/20"
                  onClick={() => setIsCategoryOpen(false)}
                >
                  <Grid className="w-4 h-4 mr-3 text-blue-500" />
                  Alle Kategorien
                </Link>
              </div>

              {/* Scrollable List */}
              <div className="py-2 max-h-[60vh] overflow-y-auto scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-slate-700">
                
                <div className="px-4 py-2 mb-1">
                  <span className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">Themenbereiche</span>
                </div>

                <ul role="none" className="space-y-0.5 px-2">
                  {CATEGORY_TREE.map((cat) => (
                    <li key={cat.label} role="none" className="mb-1 group">
                      <Link 
                        to={cat.path} 
                        role="menuitem"
                        className={`flex items-center px-3 py-2.5 rounded-lg text-sm transition-all duration-200 focus:outline-none focus:bg-blue-50 dark:focus:bg-slate-800 ${
                          location.pathname === cat.path 
                          ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400' 
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400'
                        }`}
                        onClick={() => setIsCategoryOpen(false)}
                      >
                         <span className={`w-1.5 h-1.5 rounded-full mr-3 transition-colors duration-200 ${
                           location.pathname === cat.path 
                           ? 'bg-blue-600 dark:bg-blue-400' 
                           : 'bg-gray-300 dark:bg-gray-600 group-hover:bg-blue-500'
                         }`}></span>
                         <span className="flex-grow font-medium">{cat.label}</span>
                         {cat.subItems.length > 0 && (
                           <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-blue-500 group-hover:rotate-90 transition-transform duration-300" />
                         )}
                      </Link>

                      {cat.subItems.length > 0 && (
                        <div className="grid grid-rows-[0fr] group-hover:grid-rows-[1fr] group-focus-within:grid-rows-[1fr] transition-[grid-template-rows] duration-300 ease-out delay-150 group-hover:delay-0 group-focus-within:delay-0">
                          <ul className="overflow-hidden min-h-0 pl-6 mt-0 border-l-2 border-transparent group-hover:border-gray-100 group-focus-within:border-gray-100 dark:group-hover:border-gray-800 dark:group-focus-within:border-gray-800 ml-3.5 transition-opacity duration-300 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 delay-150 group-hover:delay-200 group-focus-within:delay-0" role="group" aria-label={`Unterkategorien von ${cat.label}`}>
                            {cat.subItems.map(sub => (
                              <li key={sub.label} role="none" className="mt-1 mb-1">
                                <Link
                                  to={sub.path}
                                  role="menuitem"
                                  className={`group/sub flex items-center px-3 py-1.5 rounded-md text-sm transition-all duration-200 focus:outline-none focus:bg-blue-50 dark:focus:bg-slate-800 ${
                                    location.pathname === sub.path
                                    ? 'text-blue-600 dark:text-blue-400 font-medium bg-blue-50/50 dark:bg-blue-900/10'
                                    : 'text-gray-500 dark:text-gray-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 hover:translate-x-1'
                                  }`}
                                  onClick={() => setIsCategoryOpen(false)}
                                >
                                  <CornerDownRight className="w-3 h-3 mr-2 opacity-30 group-hover/sub:opacity-100 group-hover/sub:text-blue-500 transition-all duration-200" />
                                  {sub.label}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <Link 
            to="/compare" 
            className={`px-3 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 ${isActive('/compare') ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/10' : 'text-gray-700 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-800'}`}
          >
            Vergleiche & Tools
          </Link>
          
          {user && (
            <Link 
              to="/portfolio" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 ${isActive('/portfolio') ? 'text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/10' : 'text-gray-700 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-800'}`}
            >
              Portfolio
            </Link>
          )}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center space-x-2 md:space-x-3">
          <button className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-full transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500">
            <Search className="w-5 h-5" />
          </button>
          <button 
            onClick={toggleTheme} 
            className="p-2 text-gray-500 hover:text-amber-500 hover:bg-amber-50 dark:hover:bg-slate-800 rounded-full transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          
          {/* Auth Actions */}
          <div className="hidden md:flex items-center space-x-2 ml-2 pl-2 border-l border-gray-200 dark:border-gray-800">
            {user ? (
               <div className="flex items-center gap-3">
                 <Link to="/portfolio" className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition">
                   <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400">
                     <User className="w-4 h-4" />
                   </div>
                   <span className="hidden lg:inline max-w-[100px] truncate">{user.email}</span>
                 </Link>
                 <button 
                   onClick={logout}
                   className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-full transition"
                   title="Logout"
                 >
                   <LogOut className="w-5 h-5" />
                 </button>
               </div>
            ) : (
              <>
                <Link 
                  to="/login"
                  className="px-4 py-2 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-gray-50 dark:hover:bg-slate-800 transition"
                >
                  Login
                </Link>
                <Link 
                  to="/register"
                  className="px-4 py-2 rounded-lg text-sm font-medium bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-500/20 transition"
                >
                  Registrieren
                </Link>
              </>
            )}
          </div>

          <button 
            className="lg:hidden p-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-full transition focus:outline-none focus:ring-2 focus:ring-blue-500"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle Menu"
            aria-expanded={isMenuOpen}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`lg:hidden fixed inset-0 z-40 bg-white/95 dark:bg-slate-950/95 backdrop-blur-md transition-transform duration-300 ease-in-out ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'} pt-20 px-4 pb-6 overflow-y-auto`}>
        <div className="flex flex-col space-y-4">
          <Link 
             to="/" 
             onClick={() => setIsMenuOpen(false)}
             className="text-lg font-medium text-slate-900 dark:text-white border-b border-gray-100 dark:border-gray-800 pb-3"
          >
            Home
          </Link>
          
          <div className="space-y-3 pt-2">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">Themen</div>
            <div className="space-y-1">
              <Link 
                 to="/categories"
                 onClick={() => setIsMenuOpen(false)}
                 className="flex items-center py-2 text-base text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 font-semibold"
              >
                <Grid className="w-4 h-4 mr-2" />
                Alle Kategorien
              </Link>

              {CATEGORY_TREE.map((cat) => (
                <div key={cat.label}>
                  <Link 
                    to={cat.path} 
                    onClick={() => setIsMenuOpen(false)}
                    className="flex items-center py-2 text-base text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
                  >
                    <ChevronRight className="w-4 h-4 mr-2 text-gray-400" />
                    {cat.label}
                  </Link>
                  {cat.subItems.length > 0 && (
                    <div className="pl-8 space-y-2 mb-2">
                      {cat.subItems.map(sub => (
                         <Link
                           key={sub.label}
                           to={sub.path}
                           onClick={() => setIsMenuOpen(false)}
                           className="block text-sm text-gray-500 dark:text-gray-400 hover:text-blue-500"
                         >
                           {sub.label}
                         </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <Link to="/compare" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium text-slate-900 dark:text-white border-b border-gray-100 dark:border-gray-800 pb-3 pt-2">Vergleiche & Tools</Link>
          
          {user && (
            <Link to="/portfolio" onClick={() => setIsMenuOpen(false)} className="text-lg font-medium text-slate-900 dark:text-white border-b border-gray-100 dark:border-gray-800 pb-3">Portfolio</Link>
          )}

          {/* Mobile Auth */}
          <div className="pt-4 space-y-3">
             {user ? (
               <>
                 <div className="flex items-center gap-3 py-2 text-slate-900 dark:text-white font-medium">
                   <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
                     <User className="w-4 h-4" />
                   </div>
                   {user.email}
                 </div>
                 <button 
                   onClick={() => { logout(); setIsMenuOpen(false); }}
                   className="w-full py-3 rounded-lg border border-red-200 dark:border-red-900 text-red-600 dark:text-red-400 font-medium hover:bg-red-50 dark:hover:bg-red-900/20"
                 >
                   Logout
                 </button>
               </>
             ) : (
               <>
                 <Link 
                   to="/login"
                   onClick={() => setIsMenuOpen(false)}
                   className="block w-full text-center py-3 rounded-lg border border-gray-200 dark:border-gray-800 text-slate-900 dark:text-white font-medium hover:bg-gray-50 dark:hover:bg-slate-800"
                 >
                   Login
                 </Link>
                 <Link 
                   to="/register"
                   onClick={() => setIsMenuOpen(false)}
                   className="block w-full text-center py-3 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 shadow-lg shadow-blue-500/20"
                 >
                   Registrieren
                 </Link>
               </>
             )}
          </div>
        </div>
      </div>
    </header>
  );
};

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 dark:bg-slate-900 border-t border-gray-200 dark:border-gray-800 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          <div className="col-span-1 md:col-span-1">
             <Link to="/" className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <Activity className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-700 to-cyan-500 dark:from-blue-400 dark:to-cyan-300">
                Blockchain-Bolinger
              </span>
            </Link>
            <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">
              Dein unabhängiger Guide für Krypto, DeFi und Finanzen im DACH-Raum.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-slate-900 dark:text-white mb-4">Inhalte</h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li><Link to="/categories" className="hover:text-blue-600 dark:hover:text-blue-400">Alle Themen</Link></li>
              <li><Link to="/compare" className="hover:text-blue-600 dark:hover:text-blue-400">Vergleiche</Link></li>
              <li><Link to="/news" className="hover:text-blue-600 dark:hover:text-blue-400">News</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-slate-900 dark:text-white mb-4">Rechtliches</h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li><Link to="/impressum" className="hover:text-blue-600 dark:hover:text-blue-400">Impressum</Link></li>
              <li><Link to="/datenschutz" className="hover:text-blue-600 dark:hover:text-blue-400">Datenschutz</Link></li>
              <li><Link to="/disclaimer" className="hover:text-blue-600 dark:hover:text-blue-400">Haftungsausschluss</Link></li>
            </ul>
          </div>
          
           <div>
            <h4 className="font-bold text-slate-900 dark:text-white mb-4">Community</h4>
            <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <li><a href="#" className="hover:text-blue-600 dark:hover:text-blue-400">Newsletter</a></li>
              <li><a href="#" className="hover:text-blue-600 dark:hover:text-blue-400">Twitter / X</a></li>
              <li><a href="#" className="hover:text-blue-600 dark:hover:text-blue-400">LinkedIn</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500 dark:text-gray-400">
          <p>&copy; {new Date().getFullYear()} Blockchain-Bolinger. Alle Rechte vorbehalten.</p>
          <p className="mt-2 md:mt-0">Made with ❤️ in DACH.</p>
        </div>
      </div>
    </footer>
  );
};
