import React from 'react';
import { ArrowRight, Star, Check, ExternalLink } from 'lucide-react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  noPadding?: boolean;
}

export const Card: React.FC<CardProps> = ({ children, className = '', noPadding = false }) => {
  return (
    <div className={`bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-sm ${className}`}>
      <div className={noPadding ? '' : 'p-6'}>
        {children}
      </div>
    </div>
  );
};

export const Badge: React.FC<{ children: React.ReactNode; type?: 'success' | 'warning' | 'neutral' | 'info' }> = ({ children, type = 'neutral' }) => {
  const styles = {
    success: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400',
    warning: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400',
    info: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
    neutral: 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300',
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${styles[type]}`}>
      {children}
    </span>
  );
};

export const Button: React.FC<React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'outline' }> = ({ children, className = '', variant = 'primary', ...props }) => {
  const variants = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20',
    secondary: 'bg-slate-800 hover:bg-slate-700 text-white',
    outline: 'border border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-slate-800'
  };

  return (
    <button className={`inline-flex items-center justify-center px-4 py-2 rounded-lg text-sm font-medium transition duration-200 ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
};

export const SectionTitle: React.FC<{ title: string; subtitle?: string }> = ({ title, subtitle }) => (
  <div className="mb-8">
    <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white mb-2">{title}</h2>
    {subtitle && <p className="text-gray-600 dark:text-gray-400">{subtitle}</p>}
  </div>
);

// Specific Component for the Comparison Table
import { AffiliatePartner } from '../types';

export const AffiliateRow: React.FC<{ partner: AffiliatePartner; rank: number }> = ({ partner, rank }) => {
  return (
    <div className="relative group bg-white dark:bg-slate-900 border border-gray-200 dark:border-gray-800 rounded-xl p-4 md:p-6 flex flex-col md:flex-row items-center gap-6 hover:border-blue-500 dark:hover:border-blue-500 transition-colors shadow-sm">
      {partner.isRecommended && (
        <div className="absolute -top-3 left-6">
          <Badge type="success"><Star className="w-3 h-3 mr-1 fill-current" /> Empfehlung</Badge>
        </div>
      )}
      
      {/* Rank & Logo */}
      <div className="flex items-center gap-4 w-full md:w-1/4">
        <span className="text-2xl font-bold text-gray-300 dark:text-slate-700">#{rank}</span>
        <img src={partner.logoUrl} alt={partner.name} className="w-12 h-12 rounded-full object-cover bg-gray-100" />
        <div>
          <h3 className="font-bold text-slate-900 dark:text-white">{partner.name}</h3>
          <div className="flex items-center text-amber-400 text-sm">
            <Star className="w-4 h-4 fill-current" />
            <span className="ml-1 font-medium text-gray-600 dark:text-gray-400">{partner.rating}/5</span>
          </div>
        </div>
      </div>

      {/* Features */}
      <div className="flex-1 w-full">
        <ul className="text-sm space-y-1">
          {partner.features.slice(0, 3).map((feat, i) => (
            <li key={i} className="flex items-center text-gray-600 dark:text-gray-400">
              <Check className="w-4 h-4 text-emerald-500 mr-2 flex-shrink-0" />
              {feat}
            </li>
          ))}
        </ul>
      </div>

      {/* Bonus */}
      <div className="w-full md:w-1/5 text-center md:text-left">
        <span className="text-xs uppercase tracking-wider text-gray-500 font-bold">Bonus</span>
        <p className="text-emerald-600 dark:text-emerald-400 font-bold">{partner.bonus || 'Kein Bonus'}</p>
      </div>

      {/* CTA */}
      <div className="w-full md:w-auto flex-shrink-0">
        <a href={partner.link} target="_blank" rel="noopener noreferrer" className="block w-full">
          <Button className="w-full md:w-auto group">
            Zum Anbieter <ExternalLink className="w-4 h-4 ml-2 group-hover:translate-x-1 transition" />
          </Button>
        </a>
      </div>
    </div>
  );
};
