import React from 'react';
import { Coin, NewsArticle } from '../types';
import { TrendingUp, TrendingDown, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, Badge } from './UI';

export const CoinTickerItem: React.FC<{ coin: Coin }> = ({ coin }) => {
  const isPositive = coin.change24h >= 0;
  return (
    <Link to={`/coin/${coin.id}`} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition border border-transparent hover:border-gray-200 dark:hover:border-gray-700">
      <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-xs font-bold text-blue-600 dark:text-blue-400">
        {coin.symbol[0]}
      </div>
      <div>
        <div className="font-bold text-slate-900 dark:text-white text-sm">{coin.name}</div>
        <div className="text-xs text-gray-500">{coin.symbol}</div>
      </div>
      <div className="ml-auto text-right">
        <div className="font-mono text-sm font-medium dark:text-gray-200">€{coin.priceEur.toLocaleString('de-DE')}</div>
        <div className={`text-xs flex items-center justify-end ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
          {isPositive ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
          {Math.abs(coin.change24h)}%
        </div>
      </div>
    </Link>
  );
};

export const NewsGridItem: React.FC<{ article: NewsArticle }> = ({ article }) => {
  return (
    <Link to={`/news/${article.id}`} className="group h-full">
      <Card className="h-full overflow-hidden hover:shadow-lg transition duration-300 dark:hover:bg-slate-800/80" noPadding>
        <div className="relative h-48 overflow-hidden">
          <img 
            src={article.imageUrl} 
            alt={article.title} 
            className="w-full h-full object-cover transform group-hover:scale-105 transition duration-500" 
          />
          <div className="absolute top-4 left-4">
            <Badge type="info">{article.category}</Badge>
          </div>
        </div>
        <div className="p-6">
          <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mb-3 space-x-2">
            <span>{article.date}</span>
            <span>•</span>
            <span className="flex items-center"><Clock className="w-3 h-3 mr-1" /> {article.readTime}</span>
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition">
            {article.title}
          </h3>
          <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-3">
            {article.excerpt}
          </p>
        </div>
      </Card>
    </Link>
  );
};
