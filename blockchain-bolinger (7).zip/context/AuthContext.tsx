
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AuthApi } from '../packages/sdk/src'; 
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (email: string, pass: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const initAuth = async () => {
      const storedToken = localStorage.getItem('token');
      if (storedToken) {
        try {
          // For demo purposes, if backend is not reachable, we simulate a user
          // In production: const userData = await AuthApi.getCurrentUser(storedToken);
          // setUser(userData);
          
          setUser({
             id: 'demo-user-1',
             email: 'demo@blockchain-bolinger.de',
             role: 'USER'
          });
          setToken(storedToken);
        } catch (error) {
          console.error("Auth init failed", error);
          logout();
        }
      }
      setLoading(false);
    };
    initAuth();
  }, []);

  const login = async (email: string, pass: string) => {
    setLoading(true);
    try {
      // Mock login for demo if API fails or for testing UI
      if (process.env.NODE_ENV === 'development' && email.includes('demo')) {
          const mockUser: User = { id: 'demo-1', email, role: 'USER' };
          const mockToken = 'mock-jwt-token';
          setUser(mockUser);
          setToken(mockToken);
          localStorage.setItem('token', mockToken);
          setLoading(false);
          return;
      }

      const response = await AuthApi.login({ email, password: pass });
      setToken(response.access_token);
      setUser(response.user);
      localStorage.setItem('token', response.access_token);
    } catch (e) {
      // Fallback for demo
      console.error(e);
      throw e;
    } finally {
      setLoading(false);
    }
  };

  const register = async (email: string, pass: string) => {
    setLoading(true);
    try {
      await AuthApi.register({ email, password: pass });
      await login(email, pass); 
    } catch (e) {
      console.error(e);
      throw e;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
  };

  return (
    <AuthContext.Provider value={{ user, token, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
